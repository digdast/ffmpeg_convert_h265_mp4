$ErrorActionPreference = "Stop"
$targetDir = Join-Path $env:LOCALAPPDATA "ffmpeg-transcoder"
if ($PSScriptRoot -ne $targetDir) {
    New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
    Copy-Item -Path (Join-Path $PSScriptRoot "*") -Destination $targetDir -Recurse -Force
}
$userPath = [Environment]::GetEnvironmentVariable("Path", "User")
if (($userPath -split ";") -notcontains $targetDir) {
    $newPath = if ($userPath) { "$($userPath.TrimEnd(';'));$targetDir" } else { $targetDir }
    [Environment]::SetEnvironmentVariable("Path", $newPath, "User")
}
Write-Host "[OK] Installed FFmpeg H.265 Transcoder to $targetDir and added to Windows PATH!" -ForegroundColor Green
Write-Host "Commands available: transcode-media, ffmpeg-convert, transcode-gui, gpu-monitor" -ForegroundColor Cyan
