param([Parameter(ValueFromRemainingArguments=$true)]$RemainingArgs)
$scriptPath = Join-Path $PSScriptRoot "transcode_gui.py"
$py = Get-Command python.exe -ErrorAction SilentlyContinue | Where-Object { $_.Source -notlike "*\WindowsApps\*" } | Select-Object -First 1
if ($py) { & $py.Source $scriptPath @RemainingArgs; exit $LASTEXITCODE }
$pyLauncher = Get-Command py.exe -ErrorAction SilentlyContinue | Select-Object -First 1
if ($pyLauncher) { & $pyLauncher.Source -3 $scriptPath @RemainingArgs; exit $LASTEXITCODE }
Write-Error "Python 3 not found. Install via: winget install --id Python.Python.3.12 -e"
exit 1
