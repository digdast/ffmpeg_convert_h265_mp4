@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install_to_PATH.ps1"
pause
