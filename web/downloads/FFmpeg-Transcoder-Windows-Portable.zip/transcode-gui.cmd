@echo off
setlocal
where pythonw.exe >nul 2>nul && (start "" pythonw.exe "%~dp0transcode_gui.py" %* & exit /b 0)
where pyw.exe >nul 2>nul && (start "" pyw.exe -3 "%~dp0transcode_gui.py" %* & exit /b 0)
where python.exe >nul 2>nul && (python.exe "%~dp0transcode_gui.py" %* & exit /b %ERRORLEVEL%)
where py.exe >nul 2>nul && (py.exe -3 "%~dp0transcode_gui.py" %* & exit /b %ERRORLEVEL%)
echo [ERROR] Python 3 not found. Install via: winget install --id Python.Python.3.12 -e
exit /b 1
