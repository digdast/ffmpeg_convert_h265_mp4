@echo off
call "%~dp0transcode-gui.cmd" %*
