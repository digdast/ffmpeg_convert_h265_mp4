@echo off
setlocal
where python.exe >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    python.exe "%~dp0gpu_monitor.py" %*
    exit /b %ERRORLEVEL%
)
where py.exe >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    py.exe -3 "%~dp0gpu_monitor.py" %*
    exit /b %ERRORLEVEL%
)
echo [ERROR] Python 3 not found. Install via: winget install --id Python.Python.3.12 -e
exit /b 1
